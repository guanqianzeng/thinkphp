<div style="min-height:500px;">
    <h2>{:date('Y-m-d H:i:s')}</h2>
</div>
