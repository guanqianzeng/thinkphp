<div class="mleft">
    <ul class="ul">
        <li><a href="#">信息管理</a>
            <ul class="ul1">
                <li class="xz"><a href="01.html">基本信息</a></li>
                <li><a href="02.html">幻灯管理</a></li>
                <li><a href="#">客户列表</a></li>
                <li><a href="03.html">客户图片</a></li>
                <li><a href="#">单页管理</a></li>
                <div class="lt"></div>
            </ul>
        </li>
        <li><a href="#">新闻管理</a>
            <ul class="ul1">
                <li><a href="05.html">分类管理</a></li>
                <li><a href="04.html">信息管理</a></li>
                <div class="lt"></div>
            </ul>
        </li>
        <li><a href="#">图文管理</a>
            <ul class="ul1">
                <li><a href="05.html">分类管理</a></li>
                <li><a href="07.html">信息管理</a></li>
                <div class="lt"></div>
            </ul>
        </li>
        <li><a href="#">单页管理</a></li>
        <li><a href="#">广告管理</a>
            <ul class="ul1">
                <li><a href="#">关于我们</a></li>
                <li><a href="14.html">资讯中心</a></li>
                <li><a href="#">业务体系</a></li>
                <li><a href="#">成功案例</a></li>
                <li><a href="16.html">关于我们左侧</a></li>
                <div class="lt"></div>
            </ul>
        </li>
        <li><a href="#">系统管理</a>
            <ul class="ul1">
                <li><a href="11.html">管理员管理</a></li>
                <div class="lt"></div>
            </ul>
        </li>
    </ul>
</div>