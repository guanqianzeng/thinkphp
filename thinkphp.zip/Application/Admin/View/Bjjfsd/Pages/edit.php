<style media="screen">
    .ms select {
        padding:0px 10px;height:24px;border:solid 1px #d2d2d2;margin-right:10px; background:#fafafa
    }
    .select {width:400px;}
    .text1{height:100px;}
</style>

<form action="" method="post">
<table width="900" border="0" cellspacing="0" cellpadding="0" class="table">
    <tr>
        <td class="td1" align="right">栏目标题：</td>
        <td class="ms">
            <input type="text" readonly="readonly" value="{$cate_info['title']|default=''}" class="inputt input" />
            （栏目标题）
        </td>
    </tr>
    <tr>
        <td class="td1" align="right">内容：</td>
        <td class="ms">
            <script id="container" name="content" type="text/plain">{$info['content']|default=''|html_entity_decode}</script>
        </td>
    </tr>
    <tr>
        <td colspan="2" align="center">
             <input type="hidden" name="catid" value="{$cate_info['id']|default=0}">
             <input type="hidden" name="edit" value="{$edit}">
             <input type="submit" class="tjanniu cr" value="提 交" /><input type="reset" class="czanniu cr" value="重 置" />
        </td>
    </tr>
</table>
</form>
<js href="__COMMON__js/jquery-2.0.2.js" />
<js href="__COMMON__ueditor/ueditor.config.js" />
<js href="__COMMON__ueditor/ueditor.all.min.js" />
<script>
    $(function(){
        var ue = UE.getEditor('container',{
            serverUrl :'{:U('Admin/Tool/ueditor')}',
            initialFrameWidth : 800,
            initialFrameHeight : 450
        });
    })
</script>
