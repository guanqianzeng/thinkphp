<style media="screen">
    .ms select {
        padding:0px 10px;height:24px;border:solid 1px #d2d2d2;margin-right:10px; background:#fafafa
    }
    .select {width:400px;}
    .text1{height:100px;}
</style>

<form action="" method="post">
<table width="900" border="0" cellspacing="0" cellpadding="0" class="table">
    <tr>
        <td class="td1" align="right">管理组名称：</td>
        <td class="ms">
            <input type="text" name="title" value="{$info['title']|default=''}" class="inputt input" />
            （规则名称:后台首页）
        </td>
    </tr>
	<tr>
        <td class="td1" align="right">状态：</td>
        <td class="ms">
            <select class="select" name="status">
                    <option value="1" <eq name="info['status']" value="1">selected="selected"</eq>>正常</option>
                    <option value="0" <eq name="info['status']" value="0">selected="selected"</eq>>禁用</option>
            </select>
            （状态）
        </td>
    </tr>
    <tr>
        <td colspan="2" align="center">
             <input type="hidden" name="id" value="{$info['id']|default=''}">
             <input type="submit" class="tjanniu cr" value="提 交" /><input type="reset" class="czanniu cr" value="重 置" />
        </td>
    </tr>
</table>
</form>
