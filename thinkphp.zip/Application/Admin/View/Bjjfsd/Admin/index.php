<form>
	<div class="hdtop">
    	<a href="{:U('add')}" class="tja">添 加</a>
        <div class="clear"></div>
    </div>
    <div class="hdbot">
    <style media="screen">
        .head910 td {
            background-color:#08a3bb;
            line-height: 33px;
            color: #fff;
            font-size: 14px;
        }
    </style>
    <table width="910" border="0" cellspacing="1" cellpadding="0" class="table1 tab">
        <tr class="head910">
            <td align="center">ID</td>
            <td align="center">用户名</td>
            <td align="center">管理组</td>
            <td align="center">上次登录时间</td>
            <td align="center">状态</td>
            <td align="center">操作</td>
        </tr>
        <volist name="list" id="v">
            <tr>
                <td align="center">{$v['user_id']}</td>
                <td align="center">{$v['username']}</td>
                <td align="center">{$group_list[$v['group_id']]['title']}</td>
                <td align="center">{:date('Y/m/d H:i:s', $v['last_login_time'])}</td>
                <td align="center">
				{$v['status']?'正常':'禁用'}
				</td>
                <td align="center">
                    <a href="{:U('edit?user_id='. $v['user_id'])}" class="xga">修改</a>|
                    <a href="javascript:if(confirm('确认要执行该操作吗?')){location.href='{:U('del?user_id='. $v['user_id'])}'}" class="xga">删除</a>
                </td>
            </tr>
        </volist>
    </table>
</div>
</form>
