<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title>文件上传</title>
</head>
<body>
<div style="margin:30px;">
    <form action="upload.php" method="post" enctype="multipart/form-data">
        <input type="hidden" name="id" value="{$id}" />
        <input type="file" name="img" id="img" />
        <input type="submit" name="submit" value="提交" />
    </form>
</div>
</body>
</html>
