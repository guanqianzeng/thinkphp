<style media="screen">
    .ms select {
        padding:0px 10px;height:24px;border:solid 1px #d2d2d2;margin-right:10px; background:#fafafa
    }
    .select {width:400px;}
    .text1{height:100px;}
</style>

<form action="" method="post">
<table width="900" border="0" cellspacing="0" cellpadding="0" class="table">
    <tr>
        <td class="td1" align="right">配置标识：</td>
        <td class="ms">
            <input type="text" name="name" value="{$info['name']|default=''}" class="inputt input" />
            （用于C函数调用，只能使用英文且不能重复）
        </td>
    </tr>
    <tr>
        <td class="td1" align="right">配置标题：</td>
        <td class="ms">
            <input type="text" name="title" value="{$info['title']|default=''}" class="inputt input" />
            （用于后台显示的配置标题）
        </td>
    </tr>
    <tr>
        <td class="td1" align="right">排序：</td>
        <td class="ms">
            <input type="text" name="sort" value="{$info['sort']|default=0}" class="inputt input" />
            排序）
        </td>
    </tr>
    <tr>
        <td class="td1" align="right">配置类型：</td>
        <td class="ms">
            <select class="select" name="type">
                <volist name="Think.config.CONFIG_TYPE_LIST" id="type">
                    <option value="{$key}" <eq name="key" value="$info['type']">selected="selected"</eq>>{$type}</option>
                </volist>
            </select>
            （系统会根据不同类型解析配置值）
        </td>
    </tr>
    <tr>
        <td class="td1" align="right">配置分组：</td>
        <td class="ms">
            <select class="select" name="group">
                <option value="0">不分组</option>
                <volist name="Think.config.CONFIG_GROUP_LIST" id="group">
                    <option value="{$key}" <eq name="key" value="$info['group']">selected="selected"</eq>>{$group}</option>
                </volist>
            </select>
            （配置分组 用于批量设置 不分组则不会显示在系统设置中）
        </td>
    </tr>
    <tr>
        <td class="td1" align="right">配置值：</td>
        <td class="ms">
            <textarea class="text1" name="value">{$info.value|default=''}</textarea>
            （关键性数据）
        </td>
    </tr>
    <tr>
        <td class="td1" align="right">配置项：</td>
        <td class="ms">
            <textarea class="text1" name="extra">{$info.extra|default=''}</textarea>
            （如果是枚举型 需要配置该项）
        </td>
    </tr>
    <tr>
        <td class="td1" align="right">说明：</td>
        <td class="ms">
            <textarea class="text1" name="remark">{$info.remark|default=''}</textarea>
            （配置详细说明）
        </td>
    </tr>
    <tr>
        <td colspan="2" align="center">
             <input type="hidden" name="id" value="{$info.id|default=''}">
             <input type="submit" class="tjanniu cr" value="提 交" /><input type="reset" class="czanniu cr" value="重 置" />
        </td>
    </tr>
</table>
</form>
