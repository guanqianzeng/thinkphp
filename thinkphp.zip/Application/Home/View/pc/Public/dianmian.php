<div class="ejmrbt"><font>{$CATEGORYS[8]['english']}</font>{$CATEGORYS[8]['title']}</div>
<lists name="News" catid="8" limit="2">
    <a href="{$val['url']}" class="ak"><img src="{:thumb($val['thumb'],244,124)}" width="244"  height="124" /></a>
</lists>
