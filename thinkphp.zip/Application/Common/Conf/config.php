<?php

return array(
	//'配置项'=>'配置值'
    'MODULE_ALLOW_LIST' => array('Home','Admin'),

    'DB_TYPE' => 'mysql',
    'DB_HOST' => '192.168.1.66',
    'DB_PORT' => 3306,
    'DB_USER' => 'jfsd',
    'DB_PWD' => 'jfsd123456',
    'DB_PREFIX' => 'jfsd_',
    'DB_NAME' => 'jfsd_thinkphp',


    'DATA_CACHE_COMPRESS' => true,
    'DATA_CACHE_PREFIX' => 'jfsd_',
    'DATA_CACHE_TYPE' => 'File',


    'DEFAULT_THEME' => 'default',
    'TMPL_TEMPLATE_SUFFIX' => '.php',



    'COOKIE_EXPIRE' => 30,
    'COOKIE_DOMAIN' => '',
    'COOKIE_PREFIX' => 'jfsd_',



);
